Product Name
---------------
Crypto ICO - Cryptocurrency Website Landing Page HTML + Dashboard Template


Product Description
-------------------
Crypto ICO - Cryptocurrency Dashboard Template is fully responsive, super flexible, powerful, clean and complete solution for your crypto currencies ico start up agency. Every crypto business and their ICO have different crowdsales process for token sale. We have done deep research on required pages, process, functionalities & elements for every ICO business and provided Dashboard, Purchase Token, Wallet, Transactions, FAQ, Login history, User profile, Login, Register and many more pages UI.

Crypto ICO Admin template is powered with HTML 5, SASS, GRUNT, Gulp & Twitter Bootstrap 4 which looks great on Desktops, Tablets and Mobile Devices. Crypto ICO bootstrap admin template help ico start up agency to create their ICO Admin Dashboard easily.


Online Documentation
--------------------
You will find documentation in your downloaded zip file from ThemeForest. You can access documentation online as well.
Documentation URL: https://pixinvent.com/demo/crypto-ico-admin/documentation/

Change Log
----------
Read CHANGELOG.md file